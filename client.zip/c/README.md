<h1>Registry Test Client</h1>

1. Run setup.bat
2. Run main.exe

    call number logs will be saved in %TEMP%\CyberIsGood \
    messing with registry or deleting folders will break the exe, please run setup.bat again to fix